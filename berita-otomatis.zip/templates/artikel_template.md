---
title: "{{ title }}"
date: "{{ date }}"
source: "{{ source_name }}"
original_url: "{{ url }}"
---

![{{ image_alt }}]({{ image_url }})

{{ summary }}

[➡️ Baca selengkapnya di sumber]({{ url }})